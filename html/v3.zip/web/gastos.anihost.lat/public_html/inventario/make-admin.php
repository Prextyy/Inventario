<?php
/**
 * Script para promover usuario actual a admin
 * Ejecutar una sola vez durante la configuración inicial
 */

require_once 'config.php';
require_once 'includes/auth.php';
require_once 'includes/functions.php';

requireLogin();

if (!isAdmin()) {
    $conn = getDBConnection();
    $user_id = $_SESSION['user_id'];
    
    $sql = "UPDATE users SET role = 'admin' WHERE id = $user_id";
    
    if (mysqli_query($conn, $sql)) {
        $_SESSION['role'] = 'admin';
        echo "✓ Usuario promovido a administrador exitosamente";
        echo "<br><br>";
        echo "Redirigiendo al dashboard...";
        echo '<meta http-equiv="refresh" content="2; url=dashboard.php">';
    } else {
        echo "✗ Error al promover usuario: " . mysqli_error($conn);
    }
} else {
    echo "Este usuario ya es administrador.";
}
?>
