<?php
/**
 * Script de Actualización de Base de Datos
 * Agrega campos para imágenes y las nuevas tablas de solicitudes
 */

require_once 'config.php';
require_once 'includes/functions.php';

$conn = getDBConnection();
$errors = [];
$success = [];

// Función para verificar si una columna existe
function columnExists($conn, $table, $column) {
    $result = mysqli_query($conn, "SHOW COLUMNS FROM $table LIKE '$column'");
    return mysqli_num_rows($result) > 0;
}

// 1. Agregar columna de imagen a products
if (!columnExists($conn, 'products', 'image')) {
    $sql = "ALTER TABLE products ADD COLUMN image VARCHAR(255) AFTER qr_code";
    if (mysqli_query($conn, $sql)) {
        $success[] = "✓ Columna 'image' agregada a products";
    } else {
        $errors[] = "Error al agregar imagen: " . mysqli_error($conn);
    }
} else {
    $success[] = "✓ Columna 'image' ya existe";
}

// 2. Crear tabla de departamentos/áreas
$sql_areas = "CREATE TABLE IF NOT EXISTS areas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

if (mysqli_query($conn, $sql_areas)) {
    $success[] = "✓ Tabla 'areas' lista";
} else {
    $errors[] = "Error al crear tabla areas: " . mysqli_error($conn);
}

// 3. Agregar area_id a users
if (!columnExists($conn, 'users', 'area_id')) {
    $sql = "ALTER TABLE users ADD COLUMN area_id INT DEFAULT NULL";
    if (mysqli_query($conn, $sql)) {
        $success[] = "✓ Columna 'area_id' agregada a users";
    } else {
        $errors[] = "Error al agregar area_id: " . mysqli_error($conn);
    }
} else {
    $success[] = "✓ Columna 'area_id' ya existe";
}

// 4. Crear tabla de solicitudes
$sql_requests = "CREATE TABLE IF NOT EXISTS product_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT,
    area_id INT NOT NULL,
    user_id INT NOT NULL,
    quantity INT NOT NULL,
    status ENUM('pendiente', 'aprobado', 'rechazado', 'entregado') DEFAULT 'pendiente',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL,
    FOREIGN KEY (area_id) REFERENCES areas(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_status (status),
    INDEX idx_area (area_id),
    INDEX idx_date (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

if (mysqli_query($conn, $sql_requests)) {
    $success[] = "✓ Tabla 'product_requests' lista";
} else {
    $errors[] = "Error al crear tabla product_requests: " . mysqli_error($conn);
}

// 5. Crear tabla para productos solicitados fuera de inventario
$sql_custom = "CREATE TABLE IF NOT EXISTS custom_product_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_name VARCHAR(200) NOT NULL,
    product_description TEXT,
    area_id INT NOT NULL,
    user_id INT NOT NULL,
    quantity INT NOT NULL,
    status ENUM('pendiente', 'aprobado', 'rechazado', 'completado') DEFAULT 'pendiente',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (area_id) REFERENCES areas(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_status (status),
    INDEX idx_area (area_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

if (mysqli_query($conn, $sql_custom)) {
    $success[] = "✓ Tabla 'custom_product_requests' lista";
} else {
    $errors[] = "Error al crear tabla custom_product_requests: " . mysqli_error($conn);
}

// 6. Insertar áreas por defecto
$default_areas = [
    'Administración',
    'Recursos Humanos',
    'Contabilidad',
    'Marketing',
    'Operaciones',
    'Ventas',
    'Servicio al Cliente',
];

foreach ($default_areas as $area) {
    $area_esc = mysqli_real_escape_string($conn, $area);
    mysqli_query($conn, "INSERT IGNORE INTO areas (name) VALUES ('$area_esc')");
}
$success[] = "✓ Áreas por defecto insertadas";

// 7. Crear directorio de imágenes de productos
$uploads_dir = __DIR__ . '/uploads/products/';
if (!is_dir($uploads_dir)) {
    if (mkdir($uploads_dir, 0755, true)) {
        $success[] = "✓ Directorio 'uploads/products/' creado";
    } else {
        $errors[] = "No se pudo crear directorio 'uploads/products/'. Crea manualmente o verifica permisos.";
    }
} else {
    $success[] = "✓ Directorio 'uploads/products/' ya existe";
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Actualización de BD</title>
    <link rel="stylesheet" href="assets/css/style.css?v=4.2">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    <div class="container">
        <div class="page-header">
            <h1>🔄 Actualización de Base de Datos</h1>
        </div>

        <?php if (count($errors) > 0): ?>
            <div class="alert alert-error">
                <strong>Errores encontrados:</strong>
                <ul style="margin: 10px 0 0 20px;">
                    <?php foreach ($errors as $error): ?>
                        <li><?php echo htmlspecialchars($error); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php if (count($success) > 0): ?>
            <div class="alert alert-success">
                <strong>Actualización completada:</strong>
                <ul style="margin: 10px 0 0 20px;">
                    <?php foreach ($success as $msg): ?>
                        <li><?php echo htmlspecialchars($msg); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <div style="margin-top: 30px; padding: 20px; background: white; border-radius: 8px;">
            <h3>Próximos Pasos:</h3>
            <ol style="margin-left: 20px;">
                <li>Asigna áreas a los usuarios (ir a Gestionar Usuarios)</li>
                <li>Agrega imágenes a los productos</li>
                <li>Los usuarios podrán solicitar productos en su panel</li>
                <li>Aprueba/rechaza solicitudes en el panel de administración</li>
            </ol>
        </div>

        <a href="dashboard.php" class="btn btn-primary" style="margin-top: 20px;">← Volver</a>
    </div>
    <?php include 'includes/footer.php'; ?>
</body>
</html>
