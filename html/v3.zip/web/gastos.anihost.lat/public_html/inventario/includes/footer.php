<footer class="main-footer">
    <div class="footer-container">
        <p>&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?>. Todos los derechos reservados.</p>
    </div>
</footer>
