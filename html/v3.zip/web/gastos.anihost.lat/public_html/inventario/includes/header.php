<?php
$currentPage = basename($_SERVER['PHP_SELF'] ?? '');

$isActive = function(array $pages) use ($currentPage) {
    return in_array($currentPage, $pages, true) ? 'active' : '';
};
?>

<header class="main-header">
    <div class="header-container">
        <div class="header-left">
            <h1 class="site-title"><?php echo SITE_NAME; ?></h1>
        </div>
        <nav class="main-nav">
            <a href="dashboard.php" class="nav-link <?php echo $isActive(['dashboard.php']); ?>">Dashboard</a>
            <a href="my-requests.php" class="nav-link <?php echo $isActive(['my-requests.php']); ?>">Mis Solicitudes</a>
            <?php if (isAdmin()): ?>
                <a href="products.php" class="nav-link <?php echo $isActive(['products.php']); ?>">Productos</a>
                <a href="quick-entry.php" class="nav-link <?php echo $isActive(['quick-entry.php']); ?>">Entrada Rapida</a>
                <a href="export.php" class="nav-link <?php echo $isActive(['export.php']); ?>">Exportar</a>
                <a href="admin-users.php" class="nav-link <?php echo $isActive(['admin-users.php']); ?>">Usuarios</a>
                <a href="admin-areas.php" class="nav-link <?php echo $isActive(['admin-areas.php']); ?>">Departamentos</a>
                <a href="manage-requests.php" class="nav-link <?php echo $isActive(['manage-requests.php']); ?>">Gestionar Solicitudes</a>
                <a href="backup.php" class="nav-link <?php echo $isActive(['backup.php']); ?>">Respaldo</a>
            <?php endif; ?>
        </nav>
        <div class="header-right">
            <span class="user-name"><?php echo e(getCurrentUsername()); ?></span>
            <a href="logout.php" class="btn btn-sm btn-danger">Salir</a>
        </div>
    </div>
</header>
