<?php
require_once 'config.php';
require_once 'includes/auth.php';
require_once 'includes/functions.php';

requireLogin();

$message = '';
$error = '';
$product = null;

// Procesar búsqueda rápida de producto
if (isset($_GET['code']) && !empty($_GET['code'])) {
    $product = getProductByCode($_GET['code']);
    if (!$product) {
        $error = 'Producto no encontrado con el código: ' . htmlspecialchars($_GET['code']);
    }
}

// Procesar movimiento rápido
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['quick_movement'])) {
    $product_id = $_POST['product_id'];
    $type = $_POST['type'];
    $quantity = $_POST['quantity'];
    $reason = $_POST['reason'] ?? '';
    
    if (registerMovement($product_id, $type, $quantity, $reason)) {
        $message = 'Movimiento registrado exitosamente.';
        $product = getProduct($product_id); // Actualizar datos del producto
    } else {
        $error = 'Error al registrar el movimiento.';
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Entrada Rápida - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/style.css?v=4.2">
    <script src="assets/js/html5-qrcode.min.js"></script>
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <div class="container">
        <div class="page-header">
            <h1>Entrada Rapida</h1>
            <p>Busca productos por código o escanea el QR</p>
        </div>
        
        <?php if ($message): ?>
            <div class="alert alert-success"><?php echo e($message); ?></div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-error"><?php echo e($error); ?></div>
        <?php endif; ?>
        
        <div class="quick-entry-container">
            <div class="search-section">
                <form method="GET" class="quick-search-form" id="searchForm">
                    <div class="search-box">
                        <input 
                            type="text" 
                            name="code" 
                            id="codeInput" 
                            placeholder="Escribe o escanea el código del producto..." 
                            autofocus 
                            autocomplete="off"
                            class="quick-search-input"
                        >
                        <button type="submit" class="btn btn-primary">Buscar</button>
                    </div>
                </form>
                
                <div class="scanner-toggle">
                    <button type="button" onclick="toggleScanner()" class="btn btn-info" id="scannerBtn">
                        Activar Escaner QR
                    </button>
                </div>
                
                <div id="qr-reader" style="display: none; margin-top: 20px;"></div>
            </div>
            
            <?php if ($product): ?>
                <div class="product-card-large">
                    <div class="product-header">
                        <h2><?php echo e($product['name']); ?></h2>
                        <span class="product-code"><?php echo e($product['code']); ?></span>
                    </div>
                    
                    <div class="product-details">
                        <div class="detail-item">
                            <span class="detail-label">Categoría:</span>
                            <span class="detail-value"><?php echo e($product['category_name'] ?? 'Sin categoría'); ?></span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Stock Actual:</span>
                            <span class="detail-value">
                                <?php if ($product['quantity'] <= $product['min_stock']): ?>
                                    <span class="badge badge-danger large"><?php echo $product['quantity']; ?> unidades</span>
                                <?php else: ?>
                                    <span class="badge badge-success large"><?php echo $product['quantity']; ?> unidades</span>
                                <?php endif; ?>
                            </span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Stock Mínimo:</span>
                            <span class="detail-value"><?php echo $product['min_stock']; ?> unidades</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Precio Unitario:</span>
                            <span class="detail-value">$<?php echo number_format($product['unit_price'], 2); ?></span>
                        </div>
                    </div>
                    
                    <div class="quick-movement-form">
                        <h3>Registrar Movimiento</h3>
                        <form method="POST" id="movementForm">
                            <input type="hidden" name="quick_movement" value="1">
                            <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                            
                            <div class="movement-type-selector">
                                <label class="radio-card">
                                    <input type="radio" name="type" value="entrada" checked>
                                    <div class="radio-card-content">
                                        <span class="radio-icon">↓</span>
                                        <span class="radio-label">Entrada</span>
                                    </div>
                                </label>
                                <label class="radio-card">
                                    <input type="radio" name="type" value="salida">
                                    <div class="radio-card-content">
                                        <span class="radio-icon">↑</span>
                                        <span class="radio-label">Salida</span>
                                    </div>
                                </label>
                            </div>
                            
                            <div class="form-group">
                                <label for="quantity">Cantidad</label>
                                <input type="number" id="quantity" name="quantity" required min="1" value="1" class="large-input">
                            </div>
                            
                            <div class="form-group">
                                <label for="reason">Razón (Opcional)</label>
                                <input type="text" id="reason" name="reason" placeholder="Ej: Compra, Uso interno..." class="large-input">
                            </div>
                            
                            <div class="form-actions">
                                <button type="submit" class="btn btn-primary btn-lg">✓ Registrar Movimiento</button>
                                <button type="button" onclick="resetForm()" class="btn btn-lg">Nueva Busqueda</button>
                            </div>
                        </form>
                    </div>
                </div>
            <?php endif; ?>
            
            <div class="keyboard-shortcuts">
                <h3>Atajos de Teclado</h3>
                <ul>
                    <li><kbd>F2</kbd> - Enfocar búsqueda</li>
                    <li><kbd>F3</kbd> - Activar/Desactivar escáner QR</li>
                    <li><kbd>Tab</kbd> - Navegar entre campos</li>
                    <li><kbd>Enter</kbd> - Buscar / Registrar</li>
                    <li><kbd>Esc</kbd> - Nueva búsqueda</li>
                </ul>
            </div>
        </div>
    </div>
    
    <?php include 'includes/footer.php'; ?>
    
    <script>
        let scanner = null;
        let scannerActive = false;
        
        // Atajos de teclado
        document.addEventListener('keydown', function(e) {
            // F2 - Enfocar búsqueda
            if (e.key === 'F2') {
                e.preventDefault();
                document.getElementById('codeInput').focus();
            }
            
            // F3 - Toggle scanner
            if (e.key === 'F3') {
                e.preventDefault();
                toggleScanner();
            }
            
            // Esc - Nueva búsqueda
            if (e.key === 'Escape') {
                e.preventDefault();
                resetForm();
            }
        });
        
        function toggleScanner() {
            const readerDiv = document.getElementById('qr-reader');
            const btn = document.getElementById('scannerBtn');
            
            if (!scannerActive) {
                readerDiv.style.display = 'block';
                btn.textContent = 'Desactivar Escaner';
                btn.classList.remove('btn-info');
                btn.classList.add('btn-danger');
                startScanner();
            } else {
                readerDiv.style.display = 'none';
                btn.textContent = 'Activar Escaner QR';
                btn.classList.remove('btn-danger');
                btn.classList.add('btn-info');
                stopScanner();
            }
            
            scannerActive = !scannerActive;
        }
        
        function startScanner() {
            if (typeof Html5Qrcode === 'undefined') {
                alert('Escáner QR no disponible. Verifica la librería.');
                return;
            }
            
            scanner = new Html5Qrcode("qr-reader");
            
            scanner.start(
                { facingMode: "environment" },
                {
                    fps: 10,
                    qrbox: { width: 250, height: 250 }
                },
                (decodedText) => {
                    document.getElementById('codeInput').value = decodedText;
                    stopScanner();
                    document.getElementById('searchForm').submit();
                }
            ).catch(err => {
                console.error('Error al iniciar escáner:', err);
                alert('No se pudo acceder a la cámara. Verifica los permisos.');
            });
        }
        
        function stopScanner() {
            if (scanner) {
                scanner.stop().then(() => {
                    scanner.clear();
                }).catch(err => {
                    console.error('Error al detener escáner:', err);
                });
            }
        }
        
        function resetForm() {
            window.location.href = 'quick-entry.php';
        }
        
        // Auto-focus en cantidad si hay producto
        <?php if ($product): ?>
        document.getElementById('quantity').focus();
        document.getElementById('quantity').select();
        <?php endif; ?>
    </script>
</body>
</html>
