<?php
/**
 * Script de Upgrade de BD - Ejecutable desde Navegador
 * URL: http://gastos.anihost.lat/inventario/run-upgrade.php
 */

// Prevenir acceso desde navegador si no es local
$allowed_ips = ['127.0.0.1', 'localhost', '::1'];
$client_ip = $_SERVER['REMOTE_ADDR'] ?? '';

// Comentar esto para permitir desde cualquier IP durante la migración
// if (!in_array($client_ip, $allowed_ips)) {
//     die('Acceso denegado. Solo local.');
// }

require_once 'config.php';
require_once 'includes/auth.php';
require_once 'includes/functions.php';

echo "<h2>Ejecutando Migración de Base de Datos...</h2>";
echo "<hr>";

$conn = getDBConnection();
if (!$conn) {
    die("<p style='color:red'>ERROR: No se pudo conectar a la BD</p>");
}

echo "<p>✓ Conectado a la BD</p>";

// 1. Agregar columna de imagen a products
echo "<h3>1. Agregando soporte para imágenes...</h3>";
$sql = "ALTER TABLE products ADD COLUMN image VARCHAR(255) AFTER qr_code";
if (mysqli_query($conn, $sql)) {
    echo "<p style='color:green'>✓ Columna 'image' agregada</p>";
} else {
    if (strpos(mysqli_error($conn), "Duplicate column") !== false) {
        echo "<p style='color:blue'>ℹ Columna 'image' ya existe</p>";
    } else {
        echo "<p style='color:red'>✗ Error: " . mysqli_error($conn) . "</p>";
    }
}

// 2. Crear tabla de departamentos/áreas
echo "<h3>2. Creando tabla de áreas...</h3>";
$sql_areas = "CREATE TABLE IF NOT EXISTS areas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

if (mysqli_query($conn, $sql_areas)) {
    echo "<p style='color:green'>✓ Tabla 'areas' creada</p>";
    
    // Insertar áreas predefinidas
    $areas = [
        ['Administración', 'Departamento de Administración'],
        ['Ventas', 'Departamento de Ventas'],
        ['Compras', 'Departamento de Compras'],
        ['Almacén', 'Departamento de Almacén'],
        ['Recursos Humanos', 'Departamento de RRHH'],
        ['Contabilidad', 'Departamento de Contabilidad'],
        ['Gerencia', 'Gerencia General']
    ];
    
    foreach ($areas as $area) {
        $sql = "INSERT IGNORE INTO areas (name, description) VALUES ('" . mysqli_real_escape_string($conn, $area[0]) . "', '" . mysqli_real_escape_string($conn, $area[1]) . "')";
        mysqli_query($conn, $sql);
    }
    echo "<p style='color:green'>✓ Áreas predefinidas insertadas</p>";
} else {
    echo "<p style='color:red'>✗ Error: " . mysqli_error($conn) . "</p>";
}

// 3. Agregar area_id a users
echo "<h3>3. Agregando soporte de áreas a usuarios...</h3>";
$sql = "ALTER TABLE users ADD COLUMN area_id INT DEFAULT NULL";
if (mysqli_query($conn, $sql)) {
    echo "<p style='color:green'>✓ Columna 'area_id' agregada a users</p>";
} else {
    if (strpos(mysqli_error($conn), "Duplicate column") !== false) {
        echo "<p style='color:blue'>ℹ Columna 'area_id' ya existe</p>";
    } else {
        echo "<p style='color:red'>✗ Error: " . mysqli_error($conn) . "</p>";
    }
}

// 4. Crear tabla de solicitudes de productos
echo "<h3>4. Creando tabla de solicitudes de productos...</h3>";
$sql_requests = "CREATE TABLE IF NOT EXISTS product_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    product_id INT NOT NULL,
    area_id INT,
    quantity INT NOT NULL,
    status ENUM('pending', 'approved', 'rejected', 'delivered') DEFAULT 'pending',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    FOREIGN KEY (area_id) REFERENCES areas(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

if (mysqli_query($conn, $sql_requests)) {
    echo "<p style='color:green'>✓ Tabla 'product_requests' creada</p>";
} else {
    echo "<p style='color:red'>✗ Error: " . mysqli_error($conn) . "</p>";
}

// 5. Crear tabla de solicitudes de productos personalizados
echo "<h3>5. Creando tabla de solicitudes personalizadas...</h3>";
$sql_custom = "CREATE TABLE IF NOT EXISTS custom_product_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    area_id INT,
    product_name VARCHAR(255) NOT NULL,
    description TEXT,
    quantity INT NOT NULL,
    image VARCHAR(255),
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    admin_notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (area_id) REFERENCES areas(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

if (mysqli_query($conn, $sql_custom)) {
    echo "<p style='color:green'>✓ Tabla 'custom_product_requests' creada</p>";
} else {
    echo "<p style='color:red'>✗ Error: " . mysqli_error($conn) . "</p>";
}

// 6. Crear directorio de imágenes
echo "<h3>6. Crear directorio para imágenes...</h3>";
$upload_dir = __DIR__ . '/uploads/products';
if (!is_dir($upload_dir)) {
    if (mkdir($upload_dir, 0755, true)) {
        echo "<p style='color:green'>✓ Directorio creado: /uploads/products/</p>";
    } else {
        echo "<p style='color:blue'>ℹ Directorio ya existe</p>";
    }
} else {
    echo "<p style='color:blue'>ℹ Directorio ya existe: /uploads/products/</p>";
}

echo "<hr>";
echo "<h2 style='color:green'>✓ Migración completada exitosamente</h2>";
echo "<p><a href='dashboard.php'>← Ir al Dashboard</a></p>";
?>
