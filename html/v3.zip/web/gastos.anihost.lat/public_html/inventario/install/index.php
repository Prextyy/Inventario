<?php
session_start();

// Si ya está instalado, redirigir
if (file_exists('../config.php')) {
    header('Location: ../index.php');
    exit;
}

$step = isset($_GET['step']) ? (int)$_GET['step'] : 1;
$error = '';
$success = '';

// Procesar instalación
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($step === 1) {
        // Validar conexión a base de datos
        $db_host = $_POST['db_host'];
        $db_name = $_POST['db_name'];
        $db_user = $_POST['db_user'];
        $db_pass = $_POST['db_pass'];
        
        $conn = @mysqli_connect($db_host, $db_user, $db_pass);
        
        if (!$conn) {
            $error = 'Error: No se pudo conectar a la base de datos. Verifica tus credenciales.';
        } else {
            // Intentar crear la base de datos si no existe
            $db_created = mysqli_query($conn, "CREATE DATABASE IF NOT EXISTS `$db_name` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            
            if (!$db_created) {
                $error = 'Error: No se pudo crear la base de datos. Verifica los permisos.';
            } else {
                // Guardar datos en sesión
                $_SESSION['db_host'] = $db_host;
                $_SESSION['db_name'] = $db_name;
                $_SESSION['db_user'] = $db_user;
                $_SESSION['db_pass'] = $db_pass;
                
                mysqli_close($conn);
                header('Location: index.php?step=2');
                exit;
            }
        }
    } elseif ($step === 2) {
        // Crear usuario administrador
        $admin_user = $_POST['admin_user'];
        $admin_pass = $_POST['admin_pass'];
        $admin_email = $_POST['admin_email'];
        $site_name = $_POST['site_name'];
        
        if (empty($admin_user) || empty($admin_pass) || empty($admin_email)) {
            $error = 'Todos los campos son obligatorios.';
        } else {
            // Guardar en sesión
            $_SESSION['admin_user'] = $admin_user;
            $_SESSION['admin_pass'] = $admin_pass;
            $_SESSION['admin_email'] = $admin_email;
            $_SESSION['site_name'] = $site_name;
            
            // Proceder a crear las tablas
            require_once 'install-database.php';
            
            $install = new DatabaseInstaller(
                $_SESSION['db_host'],
                $_SESSION['db_name'],
                $_SESSION['db_user'],
                $_SESSION['db_pass']
            );
            
            if ($install->createTables()) {
                if ($install->createAdmin($admin_user, $admin_pass, $admin_email)) {
                    if ($install->createConfig($site_name)) {
                        $_SESSION['installation_complete'] = true;
                        header('Location: index.php?step=3');
                        exit;
                    } else {
                        $error = 'Error al crear el archivo de configuración.';
                    }
                } else {
                    $error = 'Error al crear el usuario administrador.';
                }
            } else {
                $error = 'Error al crear las tablas de la base de datos.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Instalación - Sistema de Inventario</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .install-container {
            background: white;
            border-radius: 12px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            max-width: 600px;
            width: 100%;
            padding: 40px;
        }
        
        .logo {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .logo h1 {
            color: #667eea;
            font-size: 32px;
            margin-bottom: 10px;
        }
        
        .logo p {
            color: #666;
            font-size: 16px;
        }
        
        .steps {
            display: flex;
            justify-content: space-between;
            margin-bottom: 40px;
        }
        
        .step {
            flex: 1;
            text-align: center;
            padding: 10px;
            position: relative;
        }
        
        .step::after {
            content: '';
            position: absolute;
            top: 20px;
            right: 0;
            width: 100%;
            height: 2px;
            background: #e0e0e0;
            z-index: -1;
        }
        
        .step:last-child::after {
            display: none;
        }
        
        .step-number {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #e0e0e0;
            color: #999;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            margin-bottom: 5px;
        }
        
        .step.active .step-number {
            background: #667eea;
            color: white;
        }
        
        .step.completed .step-number {
            background: #10b981;
            color: white;
        }
        
        .step-label {
            font-size: 12px;
            color: #666;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 500;
        }
        
        input[type="text"],
        input[type="password"],
        input[type="email"] {
            width: 100%;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 6px;
            font-size: 14px;
            transition: border-color 0.3s;
        }
        
        input:focus {
            outline: none;
            border-color: #667eea;
        }
        
        .btn {
            background: #667eea;
            color: white;
            padding: 14px 30px;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
            width: 100%;
            font-weight: 600;
            transition: background 0.3s;
        }
        
        .btn:hover {
            background: #5568d3;
        }
        
        .alert {
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 20px;
        }
        
        .alert-error {
            background: #fee;
            color: #c33;
            border: 1px solid #fcc;
        }
        
        .alert-success {
            background: #efe;
            color: #3c3;
            border: 1px solid #cfc;
        }
        
        .help-text {
            font-size: 12px;
            color: #666;
            margin-top: 5px;
        }
        
        .success-icon {
            text-align: center;
            font-size: 64px;
            color: #10b981;
            margin-bottom: 20px;
        }
        
        .success-message {
            text-align: center;
        }
        
        .success-message h2 {
            color: #333;
            margin-bottom: 10px;
        }
        
        .success-message p {
            color: #666;
            margin-bottom: 30px;
        }
    </style>
</head>
<body>
    <div class="install-container">
        <div class="logo">
            <h1>📦 Sistema de Inventario</h1>
            <p>Asistente de Instalación</p>
        </div>
        
        <div class="steps">
            <div class="step <?php echo $step >= 1 ? 'active' : ''; ?> <?php echo $step > 1 ? 'completed' : ''; ?>">
                <div class="step-number">1</div>
                <div class="step-label">Base de Datos</div>
            </div>
            <div class="step <?php echo $step >= 2 ? 'active' : ''; ?> <?php echo $step > 2 ? 'completed' : ''; ?>">
                <div class="step-number">2</div>
                <div class="step-label">Administrador</div>
            </div>
            <div class="step <?php echo $step >= 3 ? 'active' : ''; ?>">
                <div class="step-number">3</div>
                <div class="step-label">Completado</div>
            </div>
        </div>
        
        <?php if ($error): ?>
            <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <?php if ($step === 1): ?>
            <h2 style="margin-bottom: 20px;">Configuración de Base de Datos</h2>
            <form method="POST">
                <div class="form-group">
                    <label>Host de Base de Datos</label>
                    <input type="text" name="db_host" value="localhost" required>
                    <div class="help-text">Generalmente es "localhost"</div>
                </div>
                
                <div class="form-group">
                    <label>Nombre de la Base de Datos</label>
                    <input type="text" name="db_name" value="inventario" required>
                    <div class="help-text">El nombre de tu base de datos MySQL</div>
                </div>
                
                <div class="form-group">
                    <label>Usuario de Base de Datos</label>
                    <input type="text" name="db_user" required>
                </div>
                
                <div class="form-group">
                    <label>Contraseña de Base de Datos</label>
                    <input type="password" name="db_pass">
                    <div class="help-text">Deja en blanco si no tiene contraseña</div>
                </div>
                
                <button type="submit" class="btn">Continuar</button>
            </form>
        <?php elseif ($step === 2): ?>
            <h2 style="margin-bottom: 20px;">Crear Usuario Administrador</h2>
            <form method="POST">
                <div class="form-group">
                    <label>Nombre del Sitio</label>
                    <input type="text" name="site_name" value="Sistema de Inventario" required>
                </div>
                
                <div class="form-group">
                    <label>Usuario Administrador</label>
                    <input type="text" name="admin_user" required>
                </div>
                
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="admin_email" required>
                </div>
                
                <div class="form-group">
                    <label>Contraseña</label>
                    <input type="password" name="admin_pass" required>
                    <div class="help-text">Mínimo 6 caracteres</div>
                </div>
                
                <button type="submit" class="btn">Instalar</button>
            </form>
        <?php elseif ($step === 3 && isset($_SESSION['installation_complete'])): ?>
            <div class="success-icon">✓</div>
            <div class="success-message">
                <h2>¡Instalación Completada!</h2>
                <p>El sistema se ha instalado correctamente. Ya puedes empezar a usar tu sistema de inventario.</p>
                <a href="../index.php" class="btn" style="display: inline-block; text-decoration: none;">Ir al Sistema</a>
            </div>
            <?php
            // Limpiar sesión
            session_destroy();
            ?>
        <?php endif; ?>
    </div>
</body>
</html>
