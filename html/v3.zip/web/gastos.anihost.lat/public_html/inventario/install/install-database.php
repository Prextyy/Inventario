<?php

class DatabaseInstaller {
    private $conn;
    private $db_host;
    private $db_name;
    private $db_user;
    private $db_pass;
    
    public function __construct($host, $name, $user, $pass) {
        $this->db_host = $host;
        $this->db_name = $name;
        $this->db_user = $user;
        $this->db_pass = $pass;
    }
    
    private function connect() {
        $this->conn = mysqli_connect($this->db_host, $this->db_user, $this->db_pass, $this->db_name);
        
        if (!$this->conn) {
            return false;
        }
        
        mysqli_set_charset($this->conn, 'utf8mb4');
        return true;
    }
    
    public function createTables() {
        if (!$this->connect()) {
            return false;
        }
        
        // Tabla de usuarios
        $sql_users = "CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) UNIQUE NOT NULL,
            password VARCHAR(255) NOT NULL,
            email VARCHAR(100) NOT NULL,
            role ENUM('admin', 'user') DEFAULT 'user',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        
        // Tabla de categorías
        $sql_categories = "CREATE TABLE IF NOT EXISTS categories (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            description TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        
        // Tabla de productos
        $sql_products = "CREATE TABLE IF NOT EXISTS products (
            id INT AUTO_INCREMENT PRIMARY KEY,
            code VARCHAR(50) UNIQUE NOT NULL,
            name VARCHAR(200) NOT NULL,
            description TEXT,
            category_id INT,
            quantity INT DEFAULT 0,
            min_stock INT DEFAULT 5,
            unit_price DECIMAL(10,2) DEFAULT 0.00,
            qr_code VARCHAR(255),
            image VARCHAR(255),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL,
            INDEX idx_code (code),
            INDEX idx_name (name),
            INDEX idx_category (category_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        
        // Tabla de movimientos
        $sql_movements = "CREATE TABLE IF NOT EXISTS movements (
            id INT AUTO_INCREMENT PRIMARY KEY,
            product_id INT NOT NULL,
            type ENUM('entrada', 'salida') NOT NULL,
            quantity INT NOT NULL,
            reason VARCHAR(255),
            user_id INT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
            INDEX idx_product (product_id),
            INDEX idx_date (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        
        // Tabla de configuración
        $sql_settings = "CREATE TABLE IF NOT EXISTS settings (
            id INT AUTO_INCREMENT PRIMARY KEY,
            setting_key VARCHAR(50) UNIQUE NOT NULL,
            setting_value TEXT,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        
        $queries = [
            $sql_users,
            $sql_categories,
            $sql_products,
            $sql_movements,
            $sql_settings
        ];
        
        foreach ($queries as $query) {
            if (!mysqli_query($this->conn, $query)) {
                return false;
            }
        }
        
        // Insertar categorías por defecto
        $default_categories = [
            ['Papelería General', 'Artículos de oficina generales'],
            ['Escritura', 'Bolígrafos, lápices, marcadores'],
            ['Archivado', 'Carpetas, archivadores, etiquetas'],
            ['Informática', 'Artículos relacionados con computadoras'],
            ['Limpieza', 'Productos de limpieza para oficina']
        ];
        
        foreach ($default_categories as $cat) {
            $name = mysqli_real_escape_string($this->conn, $cat[0]);
            $desc = mysqli_real_escape_string($this->conn, $cat[1]);
            mysqli_query($this->conn, "INSERT IGNORE INTO categories (name, description) VALUES ('$name', '$desc')");
        }
        
        return true;
    }
    
    public function createAdmin($username, $password, $email) {
        if (!$this->conn) {
            $this->connect();
        }
        
        $username = mysqli_real_escape_string($this->conn, $username);
        $email = mysqli_real_escape_string($this->conn, $email);
        $password_hash = password_hash($password, PASSWORD_DEFAULT);
        
        $sql = "INSERT INTO users (username, password, email, role) 
                VALUES ('$username', '$password_hash', '$email', 'admin')";
        
        return mysqli_query($this->conn, $sql);
    }
    
    public function createConfig($site_name) {
        $config_content = "<?php
// Configuración de Base de Datos
define('DB_HOST', '{$this->db_host}');
define('DB_NAME', '{$this->db_name}');
define('DB_USER', '{$this->db_user}');
define('DB_PASS', '{$this->db_pass}');

// Configuración del Sitio
define('SITE_NAME', '" . addslashes($site_name) . "');
define('SITE_URL', 'http://' . \$_SERVER['HTTP_HOST'] . dirname(\$_SERVER['PHP_SELF']));

// Zona horaria
date_default_timezone_set('America/Mexico_City');

// Seguridad
define('SECURE_AUTH_KEY', '" . bin2hex(random_bytes(32)) . "');
define('SECURE_AUTH_SALT', '" . bin2hex(random_bytes(32)) . "');

// Conexión a la base de datos
function getDBConnection() {
    static \$conn = null;
    
    if (\$conn === null) {
        \$conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        
        if (!\$conn) {
            die('Error de conexión: ' . mysqli_connect_error());
        }
        
        mysqli_set_charset(\$conn, 'utf8mb4');
    }
    
    return \$conn;
}
";
        
        return file_put_contents('../config.php', $config_content) !== false;
    }
}
