<?php
session_start();

// Verificar si ya está instalado
if (!file_exists('config.php')) {
    header('Location: install.php');
    exit();
}

require_once 'config.php';
require_once 'includes/functions.php';

// Verificar si el usuario está logueado
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$db = getDBConnection();
$stats = getInventoryStats($db);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Inventario - Papelería</title>
    <link rel="stylesheet" href="assets/css/style.css?v=4.2">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <!-- Header -->
        <header class="header">
            <div class="header-content">
                <h1><i class="fas fa-boxes"></i> Sistema de Inventario</h1>
                <div class="user-info">
                    <span>Bienvenido, <?php echo htmlspecialchars($_SESSION['username']); ?></span>
                    <a href="logout.php" class="btn btn-secondary"><i class="fas fa-sign-out-alt"></i> Salir</a>
                </div>
            </div>
        </header>

        <!-- Stats Dashboard -->
        <div class="stats-container">
            <div class="stat-card">
                <div class="stat-icon"><i class="fas fa-box"></i></div>
                <div class="stat-info">
                    <h3><?php echo $stats['total_productos']; ?></h3>
                    <p>Total Productos</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon"><i class="fas fa-clipboard-list"></i></div>
                <div class="stat-info">
                    <h3><?php echo $stats['total_categorias']; ?></h3>
                    <p>Categorías</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon"><i class="fas fa-exclamation-triangle"></i></div>
                <div class="stat-info">
                    <h3><?php echo $stats['stock_bajo']; ?></h3>
                    <p>Stock Bajo</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon"><i class="fas fa-dollar-sign"></i></div>
                <div class="stat-info">
                    <h3>$<?php echo number_format($stats['valor_total'], 2); ?></h3>
                    <p>Valor Total</p>
                </div>
            </div>
        </div>

        <!-- Main Navigation -->
        <nav class="main-nav">
            <a href="productos.php" class="nav-btn" accesskey="p">
                <i class="fas fa-box-open"></i>
                <span>Gestión de Productos</span>
                <small>Alt+P</small>
            </a>
            <a href="categorias.php" class="nav-btn" accesskey="c">
                <i class="fas fa-tags"></i>
                <span>Categorías</span>
                <small>Alt+C</small>
            </a>
            <a href="export.php" class="nav-btn" accesskey="e">
                <i class="fas fa-file-export"></i>
                <span>Exportar Datos</span>
                <small>Alt+E</small>
            </a>
            <a href="reportes.php" class="nav-btn" accesskey="r">
                <i class="fas fa-chart-bar"></i>
                <span>Reportes</span>
                <small>Alt+R</small>
            </a>
        </nav>

        <!-- Quick Actions -->
        <div class="quick-actions">
            <h2>Acciones Rápidas</h2>
            <div class="action-buttons">
                <a href="productos.php?action=nuevo" class="action-btn primary">
                    <i class="fas fa-plus-circle"></i> Agregar Producto Nuevo
                </a>
                <a href="scan.php" class="action-btn secondary">
                    <i class="fas fa-qrcode"></i> Escanear Código QR
                </a>
            </div>
        </div>

        <!-- Recent Products -->
        <div class="recent-section">
            <h2>Productos Recientes</h2>
            <div class="table-responsive">
                <?php
                $recent = getRecentProducts($db, 5);
                if (count($recent) > 0) {
                    echo '<table class="data-table">
                        <thead>
                            <tr>
                                <th>Código</th>
                                <th>Nombre</th>
                                <th>Categoría</th>
                                <th>Stock</th>
                                <th>Precio</th>
                                <th>Estado</th>
                            </tr>
                        </thead>
                        <tbody>';
                    foreach ($recent as $producto) {
                        $stock_class = $producto['cantidad'] <= $producto['stock_minimo'] ? 'stock-bajo' : 'stock-ok';
                        echo '<tr>
                            <td>' . htmlspecialchars($producto['codigo']) . '</td>
                            <td>' . htmlspecialchars($producto['nombre']) . '</td>
                            <td>' . htmlspecialchars($producto['categoria']) . '</td>
                            <td class="' . $stock_class . '">' . $producto['cantidad'] . '</td>
                            <td>$' . number_format($producto['precio'], 2) . '</td>
                            <td><span class="badge badge-' . ($producto['activo'] ? 'success' : 'danger') . '">' . 
                                ($producto['activo'] ? 'Activo' : 'Inactivo') . '</span></td>
                        </tr>';
                    }
                    echo '</tbody></table>';
                } else {
                    echo '<p class="no-data">No hay productos registrados. <a href="productos.php?action=nuevo">Agrega tu primer producto</a></p>';
                }
                ?>
            </div>
        </div>
    </div>

    <script src="assets/js/main.js"></script>
</body>
</html>
