<?php
session_start();
require_once 'config.php';
require_once 'includes/functions.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$db = getDBConnection();

// Exportar a PDF
if (isset($_GET['type']) && $_GET['type'] === 'pdf') {
    require_once 'includes/pdf_export.php';
    $productos = getAllProducts($db);
    generatePDF($productos, $_SESSION['nombre']);
    exit();
}

// Exportar a Excel (para trabajadores - sin cantidades)
if (isset($_GET['type']) && $_GET['type'] === 'excel_catalogo') {
    require_once 'includes/excel_export.php';
    $productos = getAllProducts($db);
    generateCatalogExcel($productos);
    exit();
}

// Exportar a Excel (completo - con cantidades)
if (isset($_GET['type']) && $_GET['type'] === 'excel_completo') {
    require_once 'includes/excel_export.php';
    $productos = getAllProducts($db);
    generateFullExcel($productos);
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exportar Datos - Sistema de Inventario</title>
    <link rel="stylesheet" href="assets/css/style.css?v=4.2">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <header class="header">
            <div class="header-content">
                <h1><i class="fas fa-file-export"></i> Exportar Datos</h1>
                <div class="header-actions">
                    <a href="dashboard.php" class="btn btn-secondary"><i class="fas fa-home"></i> Inicio</a>
                </div>
            </div>
        </header>

        <div class="export-container">
            <!-- Exportar PDF -->
            <div class="export-card">
                <div class="export-icon">
                    <i class="fas fa-file-pdf"></i>
                </div>
                <h2>Exportar a PDF</h2>
                <p>Genera un reporte completo en PDF con toda la información del inventario incluyendo cantidades, precios y valores totales.</p>
                <ul class="export-features">
                    <li><i class="fas fa-check"></i> Información completa de productos</li>
                    <li><i class="fas fa-check"></i> Cantidades y precios</li>
                    <li><i class="fas fa-check"></i> Valores totales</li>
                    <li><i class="fas fa-check"></i> Formato profesional</li>
                </ul>
                <a href="export.php?type=pdf" class="btn btn-primary btn-block" target="_blank">
                    <i class="fas fa-file-pdf"></i> Descargar PDF Completo
                </a>
            </div>

            <!-- Exportar Excel Catálogo -->
            <div class="export-card">
                <div class="export-icon icon-success">
                    <i class="fas fa-file-excel"></i>
                </div>
                <h2>Catálogo para Trabajadores</h2>
                <p>Genera un archivo Excel con el catálogo de productos <strong>sin mostrar cantidades ni precios</strong>, ideal para compartir con trabajadores.</p>
                <ul class="export-features">
                    <li><i class="fas fa-check"></i> Lista de productos disponibles</li>
                    <li><i class="fas fa-check"></i> Códigos y descripciones</li>
                    <li><i class="fas fa-times feature-off"></i> Sin cantidades</li>
                    <li><i class="fas fa-times feature-off"></i> Sin precios</li>
                </ul>
                <a href="export.php?type=excel_catalogo" class="btn btn-success btn-block">
                    <i class="fas fa-file-excel"></i> Descargar Catálogo Excel
                </a>
            </div>

            <!-- Exportar Excel Completo -->
            <div class="export-card">
                <div class="export-icon icon-info">
                    <i class="fas fa-file-excel"></i>
                </div>
                <h2>Excel Completo (Administrador)</h2>
                <p>Genera un archivo Excel con toda la información del inventario incluyendo cantidades, precios y cálculos.</p>
                <ul class="export-features">
                    <li><i class="fas fa-check"></i> Información completa</li>
                    <li><i class="fas fa-check"></i> Cantidades y stock</li>
                    <li><i class="fas fa-check"></i> Precios y valores</li>
                    <li><i class="fas fa-check"></i> Editable en Excel</li>
                </ul>
                <a href="export.php?type=excel_completo" class="btn btn-info btn-block">
                    <i class="fas fa-file-excel"></i> Descargar Excel Completo
                </a>
            </div>
        </div>

        <div class="card">
            <h2><i class="fas fa-info-circle"></i> Información</h2>
            <div class="info-content">
                <p><strong>Recomendaciones:</strong></p>
                <ul>
                    <li>El <strong>PDF</strong> es ideal para imprimir reportes o enviar por correo.</li>
                    <li>El <strong>Catálogo Excel</strong> es perfecto para compartir con trabajadores que solo necesitan saber qué productos hay disponibles.</li>
                    <li>El <strong>Excel Completo</strong> es para uso administrativo con toda la información sensible.</li>
                </ul>
            </div>
        </div>
    </div>
</body>
</html>
