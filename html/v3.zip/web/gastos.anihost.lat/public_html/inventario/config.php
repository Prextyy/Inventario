<?php
/**
 * Archivo de Configuración
 * Sistema de Inventario - HestiaCP
 */

// Configuración de Base de Datos
define('DB_HOST', 'localhost');
define('DB_NAME', 'Prexty_inventarios');
define('DB_USER', 'Prexty_invent');
define('DB_PASS', 'fwDoxH&b){{yN2kk');

// Configuración del Sitio
define('SITE_NAME', 'Sistema de Inventario');
define('SITE_URL', 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']));

// Zona horaria
date_default_timezone_set('America/Mexico_City');

// Seguridad
define('SECURE_AUTH_KEY', '3ee126759ceaf7449e4f8b6c2dabac8e3bfc91b8dc2fdbbcfec1ed6a9cb4e4fd');
define('SECURE_AUTH_SALT', 'd74e205f90d3de0bb95d8bad133bfba061e34330aa0f2605d75426b54482dff6');

// Conexión a la base de datos
function getDBConnection() {
    static $conn = null;
    
    if ($conn === null) {
        $conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        
        if (!$conn) {
            die('Error de conexión: ' . mysqli_connect_error());
        }
        
        mysqli_set_charset($conn, 'utf8mb4');
    }
    
    return $conn;
}
